//go:build debug
// +build debug

package rss

const debug = true

const DATE = "Mon 2 Jan 2006 15:04:05 MST"
