//go:build !debug
// +build !debug

package rss

const debug = false

// DATE is a constant date string.
const DATE = "15:04:05 MST 02/01/2006"
